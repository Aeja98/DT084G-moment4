# Labbgrund till Moment 4 i kursen DT084G, Introdktion till programmering i JavaScript

Angelica Adolfsson (anad2400)
Moment 4 DOM & händelsehantering - 17 Oktober 2024

I denna uppgift skulle vi klona ner ett repo till vår dator och göra ändringar i Visual Studio Code för att skapa en to do list som går att interagera med.

Det ska finnas möjlighet att lägga till saker till listan som är minst fem tecken lång, radera både enskilda eller allting från listan, samt spara i webb storage.

För att skapa webbsidan behövs flera olika funktioner och händelsehanterare som kopplar koden i javascript till webbsidan i html.
